import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class DownloadFile {
    private static BufferedInputStream bufferedInputStream = null;
    private static FileOutputStream fileOutputStream = null;

    public DownloadFile(String url, String file){
        try {
            bufferedInputStream = new BufferedInputStream(new URL(url).openStream());
            fileOutputStream = new FileOutputStream(file);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run(){
        final byte data[] = new byte[4096];
        int count;
        try {
            while ((count = bufferedInputStream.read(data, 0, 4096)) != -1) {
                fileOutputStream.write(data, 0, count);
                fileOutputStream.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close(){
        try {
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
