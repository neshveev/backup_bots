import org.json.JSONException;
import org.json.JSONObject;

public class App {
    public static void main(String[] args) {
        MqManager mqManager = new MqManager();
        mqManager.createQuIn("VideoDownloadIn");
        mqManager.createQuOut("AudioExtractIn");

        while (true) {
            String mqMessage = mqManager.consumer();
            JSONObject message = new JSONObject(mqMessage);
            try {
                String work_id = message.getString("work-id");
                String url = message.getString("url");
                String fileName = message.getString("fileName");
                String format = fileName.substring(fileName.indexOf("."));
                String file = "/home/ejommy/Documents/serena1.0/video/" + work_id + format;
                if (url.startsWith("https://yadi.sk/d/")){
                    url = url + "/" + fileName;
                }
                DownloadFile downloadFile = new DownloadFile("https://getfile.dokpub.com/yandex/get/" + url, file);
                downloadFile.run();
                downloadFile.close();
                message.put("path", file);
                System.out.println(message.toString());
                mqManager.producer(message.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
